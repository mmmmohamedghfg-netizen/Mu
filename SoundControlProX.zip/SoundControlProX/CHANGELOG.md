# Changelog

## 1.0.0
- Initial Media3 playback service and local music library.
- Real Equalizer, BassBoost, Virtualizer, and LoudnessEnhancer integration.
- Audio diagnostics and Arabic/English localization.
