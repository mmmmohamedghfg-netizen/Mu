# Sound Control Pro X

A no-root Android audio app built with Kotlin, Jetpack Compose, Material 3, MVVM, and AndroidX Media3.

## Implemented
- Offline local music playback using Media3 ExoPlayer and MediaSession.
- Real Android Equalizer attached to this app's own playback audio session.
- Real BassBoost, Virtualizer, and LoudnessEnhancer when supported.
- Runtime diagnostics using actual Android effect availability.
- MediaStore music library, playback controls, Arabic/English localization and RTL.
- Adaptive launcher icon with monochrome themed-icon support.

## Limitation
Android does not allow a regular app to change another app's equalizer or audio effects. All effects apply only to Sound Control Pro X's own Media3 playback session.

## Build
```bash
gradle assembleDebug
```

APK output:
```text
app/build/outputs/apk/debug/app-debug.apk
```
