package com.soundcontrolprox.ui

import android.Manifest
import android.content.ComponentName
import android.os.Build
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.runtime.*
import androidx.core.content.ContextCompat
import androidx.media3.session.MediaController
import androidx.media3.session.SessionToken
import com.soundcontrolprox.playback.PlaybackService
import com.soundcontrolprox.ui.screens.SoundControlApp

class MainActivity : ComponentActivity() {
    private var controller: MediaController? = null
    private val permissionLauncher = registerForActivityResult(ActivityResultContracts.RequestMultiplePermissions()) { }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        requestAudioPermissions()
        val future = MediaController.Builder(this, SessionToken(this, ComponentName(this, PlaybackService::class.java))).buildAsync()
        future.addListener({ controller = future.get() }, ContextCompat.getMainExecutor(this))
        setContent { SoundControlApp(controller = controller, onRequestPermissions = { requestAudioPermissions() }) }
    }

    private fun requestAudioPermissions() {
        val permissions = if (Build.VERSION.SDK_INT >= 33)
            arrayOf(Manifest.permission.READ_MEDIA_AUDIO, Manifest.permission.POST_NOTIFICATIONS)
        else arrayOf(Manifest.permission.READ_EXTERNAL_STORAGE)
        permissionLauncher.launch(permissions)
    }

    override fun onDestroy() {
        controller?.release(); controller = null
        super.onDestroy()
    }
}
