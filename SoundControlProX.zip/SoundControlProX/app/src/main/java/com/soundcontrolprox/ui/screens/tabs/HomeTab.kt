package com.soundcontrolprox.ui.screens.tabs

import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.media3.session.MediaController
import com.soundcontrolprox.R
import com.soundcontrolprox.audio.AudioEngine

@Composable
fun HomeTab(controller: MediaController?) {
    val caps by AudioEngine.capabilities.collectAsState()
    val enabled by AudioEngine.enabled.collectAsState()
    Column(Modifier.fillMaxSize().padding(16.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(stringResource(R.string.app_name), style = MaterialTheme.typography.headlineSmall)
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(stringResource(R.string.audio_effects_status))
                Text(stringResource(R.string.equalizer) + ": " + if (caps.equalizer) stringResource(R.string.supported) else stringResource(R.string.unsupported))
                Text(stringResource(R.string.bass_boost) + ": " + if (caps.bassBoost) stringResource(R.string.supported) else stringResource(R.string.unsupported))
                Text(stringResource(R.string.virtualizer) + ": " + if (caps.virtualizer) stringResource(R.string.supported) else stringResource(R.string.unsupported))
                Text(stringResource(R.string.loudness) + ": " + if (caps.loudness) stringResource(R.string.supported) else stringResource(R.string.unsupported))
            }
        }
        Card(Modifier.fillMaxWidth()) {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(stringResource(R.string.playback))
                Text(controller?.currentMediaItem?.mediaMetadata?.title?.toString() ?: stringResource(R.string.no_track))
                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                    Button(onClick = { controller?.seekToPrevious() }) { Text(stringResource(R.string.previous)) }
                    Button(onClick = { if (controller?.isPlaying == true) controller.pause() else controller?.play() }) {
                        Text(if (controller?.isPlaying == true) stringResource(R.string.pause) else stringResource(R.string.play))
                    }
                    Button(onClick = { controller?.seekToNext() }) { Text(stringResource(R.string.next)) }
                }
            }
        }
        Button(onClick = { AudioEngine.setEnabled(!enabled) }) {
            Text(if (enabled) stringResource(R.string.disable_effects) else stringResource(R.string.enable_effects))
        }
    }
}
