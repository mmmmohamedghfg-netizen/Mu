package com.soundcontrolprox.ui.screens

import androidx.compose.foundation.layout.*
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.vector.ImageVector
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.media3.session.MediaController
import com.soundcontrolprox.R
import com.soundcontrolprox.ui.screens.tabs.*

private data class Tab(val icon: ImageVector, val labelRes: Int)

@Composable
fun SoundControlApp(controller: MediaController?, onRequestPermissions: () -> Unit) {
    var selected by remember { mutableIntStateOf(0) }
    val tabs = listOf(
        Tab(Icons.Filled.Home, R.string.home),
        Tab(Icons.Filled.Equalizer, R.string.equalizer),
        Tab(Icons.Filled.MusicNote, R.string.music),
        Tab(Icons.Filled.GraphicEq, R.string.effects),
        Tab(Icons.Filled.MonitorHeart, R.string.diagnostics)
    )
    Scaffold(
        bottomBar = {
            NavigationBar {
                tabs.forEachIndexed { index, tab ->
                    NavigationBarItem(
                        selected = selected == index,
                        onClick = { selected = index },
                        icon = { Icon(tab.icon, contentDescription = null) },
                        label = { Text(stringResource(tab.labelRes)) }
                    )
                }
            }
        }
    ) { padding ->
        Box(Modifier.padding(padding)) {
            when (selected) {
                0 -> HomeTab(controller)
                1 -> EqualizerTab()
                2 -> PlayerTab(controller, onRequestPermissions)
                3 -> EffectsTab()
                else -> DiagnosticsTab()
            }
        }
    }
}
