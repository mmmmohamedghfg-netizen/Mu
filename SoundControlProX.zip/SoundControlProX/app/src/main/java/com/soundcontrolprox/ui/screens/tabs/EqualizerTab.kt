package com.soundcontrolprox.ui.screens.tabs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.soundcontrolprox.R
import com.soundcontrolprox.audio.AudioEngine

@Composable
fun EqualizerTab() {
    val caps by AudioEngine.capabilities.collectAsState()
    val enabled by AudioEngine.enabled.collectAsState()
    val presets = remember(caps.bandCount) { AudioEngine.presetNames() }
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text(stringResource(R.string.equalizer), style = MaterialTheme.typography.headlineSmall)
        if (!caps.equalizer) {
            Card { Text(Modifier.padding(16.dp), stringResource(R.string.equalizer_unsupported)) }
            return@Column
        }
        Button(onClick = { AudioEngine.setEnabled(!enabled) }) {
            Text(if (enabled) stringResource(R.string.disable) else stringResource(R.string.enable))
        }
        if (presets.isNotEmpty()) {
            Text(stringResource(R.string.presets))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                presets.forEachIndexed { index, name ->
                    OutlinedButton(onClick = { AudioEngine.usePreset(index.toShort()) }) { Text(name) }
                }
            }
        }
        val range = AudioEngine.bandRange()
        for (band in 0 until caps.bandCount) {
            val bandShort = band.toShort()
            var level by remember(band, caps) { mutableFloatStateOf(AudioEngine.bandLevel(bandShort).toFloat()) }
            Text(AudioEngine.centerFrequency(bandShort).toString() + " Hz: " + level.toInt() + " dB")
            Slider(
                value = level,
                onValueChange = { level = it; AudioEngine.setBandLevel(bandShort, it.toInt().toShort()) },
                valueRange = range.first.toFloat()..range.second.toFloat()
            )
        }
    }
}
