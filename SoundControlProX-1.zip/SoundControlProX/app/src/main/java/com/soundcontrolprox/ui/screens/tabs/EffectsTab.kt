package com.soundcontrolprox.ui.screens.tabs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.soundcontrolprox.R
import com.soundcontrolprox.audio.AudioEngine

@Composable
fun EffectsTab() {
    val caps by AudioEngine.capabilities.collectAsState()
    var bass by remember(caps) { mutableFloatStateOf(AudioEngine.bassStrength().toFloat()) }
    var virtual by remember(caps) { mutableFloatStateOf(AudioEngine.virtualizerStrength().toFloat()) }
    var loudness by remember(caps) { mutableFloatStateOf(AudioEngine.loudnessGain()) }
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        Text(stringResource(R.string.effects), style = MaterialTheme.typography.headlineSmall)
        if (caps.bassBoost) {
            Text(stringResource(R.string.bass_boost) + ": " + bass.toInt())
            Slider(
                value = bass,
                onValueChange = { bass = it; AudioEngine.setBassStrength(it.toInt().toShort()) },
                valueRange = 0f..1000f,
                onValueChangeFinished = { AudioEngine.applySafeGain() }
            )
        } else Text(stringResource(R.string.bass_boost_unsupported))
        if (caps.virtualizer) {
            Text(stringResource(R.string.virtualizer) + ": " + virtual.toInt())
            Slider(value = virtual, onValueChange = { virtual = it; AudioEngine.setVirtualizerStrength(it.toInt().toShort()) }, valueRange = 0f..1000f)
        } else Text(stringResource(R.string.virtualizer_unsupported))
        if (caps.loudness) {
            Text(stringResource(R.string.loudness) + ": " + "%.1f".format(loudness) + " dB")
            Slider(value = loudness, onValueChange = { loudness = it; AudioEngine.setLoudnessGain(it) }, valueRange = -12f..6f)
        } else Text(stringResource(R.string.loudness_unsupported))
    }
}
