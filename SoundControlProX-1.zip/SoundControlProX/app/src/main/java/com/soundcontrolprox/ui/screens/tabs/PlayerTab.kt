package com.soundcontrolprox.ui.screens.tabs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import androidx.media3.common.MediaItem
import androidx.media3.session.MediaController
import com.soundcontrolprox.R
import com.soundcontrolprox.data.MusicRepository

@Composable
fun PlayerTab(controller: MediaController?, onRequestPermissions: () -> Unit) {
    val context = LocalContext.current
    var songs by remember { mutableStateOf(listOf<com.soundcontrolprox.data.Song>()) }
    LaunchedEffect(Unit) { songs = MusicRepository.loadSongs(context) }
    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Row(Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
            Text(stringResource(R.string.music), style = MaterialTheme.typography.headlineSmall)
            TextButton(onClick = onRequestPermissions) { Text(stringResource(R.string.refresh)) }
        }
        if (songs.isEmpty()) Text(stringResource(R.string.no_music_found))
        LazyColumn(Modifier.fillMaxSize()) {
            items(songs) { song ->
                ListItem(
                    headlineContent = { Text(song.title) },
                    supportingContent = { Text(song.artist + " - " + song.album) },
                    trailingContent = {
                        TextButton(onClick = {
                            controller?.setMediaItem(MediaItem.fromUri(song.uri))
                            controller?.prepare(); controller?.play()
                        }) { Text(stringResource(R.string.play)) }
                    }
                )
                HorizontalDivider()
            }
        }
    }
}
