package com.soundcontrolprox.audio

import android.media.audiofx.BassBoost
import android.media.audiofx.Equalizer
import android.media.audiofx.LoudnessEnhancer
import android.media.audiofx.Virtualizer
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow

data class EffectCapabilities(
    val equalizer: Boolean = false,
    val bassBoost: Boolean = false,
    val virtualizer: Boolean = false,
    val loudness: Boolean = false,
    val bandCount: Int = 0,
    val error: String? = null
)

object AudioEngine {
    private var equalizer: Equalizer? = null
    private var bassBoost: BassBoost? = null
    private var virtualizer: Virtualizer? = null
    private var loudness: LoudnessEnhancer? = null
    private val _capabilities = MutableStateFlow(EffectCapabilities())
    val capabilities = _capabilities.asStateFlow()
    private val _enabled = MutableStateFlow(true)
    val enabled = _enabled.asStateFlow()

    fun attach(audioSessionId: Int) {
        release()
        var error: String? = null
        try { equalizer = Equalizer(0, audioSessionId).also { it.enabled = true } } catch (e: Exception) { error = e.message }
        try { bassBoost = BassBoost(0, audioSessionId).also { it.enabled = true } } catch (e: Exception) { error = error ?: e.message }
        try { virtualizer = Virtualizer(0, audioSessionId).also { it.enabled = true } } catch (e: Exception) { error = error ?: e.message }
        try { loudness = LoudnessEnhancer(audioSessionId).also { it.enabled = true } } catch (e: Exception) { error = error ?: e.message }
        _capabilities.value = EffectCapabilities(
            equalizer = equalizer != null,
            bassBoost = bassBoost != null,
            virtualizer = virtualizer != null,
            loudness = loudness != null,
            bandCount = equalizer?.numberOfBands?.toInt() ?: 0,
            error = error
        )
    }

    fun setEnabled(value: Boolean) {
        _enabled.value = value
        listOf(equalizer, bassBoost, virtualizer, loudness).forEach { it?.enabled = value }
    }

    fun bandCount(): Int = equalizer?.numberOfBands?.toInt() ?: 0

    fun bandRange(): Pair<Short, Short> {
        val range = equalizer?.bandLevelRange ?: return Pair(0.toShort(), 0.toShort())
        return Pair(range[0], range[1])
    }

    fun bandLevel(band: Short): Short = equalizer?.getBandLevel(band) ?: 0.toShort()

    fun setBandLevel(band: Short, level: Short) {
        val range = bandRange()
        val safeLevel = level.coerceIn(range.first, range.second)
        equalizer?.setBandLevel(band, safeLevel)
    }

    fun centerFrequency(band: Short): Int = (equalizer?.getCenterFreq(band) ?: 0) / 1000

    fun presetNames(): List<String> {
        val equalizerEffect = equalizer ?: return emptyList()
        return (0 until equalizerEffect.numberOfPresets).map { equalizerEffect.getPresetName(it.toShort()) }
    }

    fun usePreset(index: Short) { equalizer?.usePreset(index) }

    fun setBassStrength(strength: Short) {
        bassBoost?.setStrength(strength.coerceIn(0, 1000))
    }

    fun bassStrength(): Short = bassBoost?.roundedStrength ?: 0.toShort()

    fun setVirtualizerStrength(strength: Short) {
        virtualizer?.setStrength(strength.coerceIn(0, 1000))
    }

    fun virtualizerStrength(): Short = virtualizer?.roundedStrength ?: 0.toShort()

    fun setLoudnessGain(db: Float) {
        loudness?.setTargetGain(db.coerceIn(-12f, 6f))
    }

    fun loudnessGain(): Float = loudness?.targetGain ?: 0f

    fun applySafeGain() {
        if (!capabilities.value.loudness) return
        var total = 0f
        for (band in 0 until bandCount()) total += bandLevel(band.toShort())
        val average = if (bandCount() == 0) 0f else total / bandCount()
        val compensation = if (average > 3f) -(average - 3f).coerceAtMost(6f) else 0f
        setLoudnessGain(compensation)
    }

    fun resetEqualizer() {
        for (band in 0 until bandCount()) setBandLevel(band.toShort(), 0.toShort())
    }

    fun release() {
        listOf(equalizer, bassBoost, virtualizer, loudness).forEach { runCatching { it?.release() } }
        equalizer = null; bassBoost = null; virtualizer = null; loudness = null
        _capabilities.value = EffectCapabilities()
    }
}
