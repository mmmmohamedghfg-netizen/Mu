package com.soundcontrolprox.ui.screens.tabs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.soundcontrolprox.R
import com.soundcontrolprox.audio.AudioEngine

@Composable
fun DiagnosticsTab() {
    val caps by AudioEngine.capabilities.collectAsState()
    Column(Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()), verticalArrangement = Arrangement.spacedBy(10.dp)) {
        Text(stringResource(R.string.diagnostics), style = MaterialTheme.typography.headlineSmall)
        Text(stringResource(R.string.diagnostics_note), style = MaterialTheme.typography.bodySmall)
        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(6.dp)) {
                Text(stringResource(R.string.equalizer) + ": " + if (caps.equalizer) stringResource(R.string.supported) else stringResource(R.string.unsupported))
                Text(stringResource(R.string.bass_boost) + ": " + if (caps.bassBoost) stringResource(R.string.supported) else stringResource(R.string.unsupported))
                Text(stringResource(R.string.virtualizer) + ": " + if (caps.virtualizer) stringResource(R.string.supported) else stringResource(R.string.unsupported))
                Text(stringResource(R.string.loudness) + ": " + if (caps.loudness) stringResource(R.string.supported) else stringResource(R.string.unsupported))
                Text(stringResource(R.string.bands) + ": " + caps.bandCount)
                caps.error?.let { Text(stringResource(R.string.initialization_error) + ": " + it, color = MaterialTheme.colorScheme.error) }
            }
        }
    }
}
