package com.soundcontrolprox.audio

import android.content.Context
import android.media.AudioDeviceCallback
import android.media.AudioDeviceInfo
import android.media.AudioManager
import com.soundcontrolprox.data.ProfileStore
import kotlinx.coroutines.CoroutineScope
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.SupervisorJob
import kotlinx.coroutines.launch

object DeviceProfileManager {
    private val scope = CoroutineScope(SupervisorJob() + Dispatchers.Main)
    private var appContext: Context? = null
    private var callback: AudioDeviceCallback? = null

    fun deviceKey(device: AudioDeviceInfo): String =
        device.type.toString() + ":" + (device.address ?: "")

    fun currentDeviceKey(context: Context): String? {
        val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        val devices = audioManager.getDevices(AudioManager.GET_DEVICES_OUTPUTS)
        val preferred = devices.firstOrNull {
            it.type == AudioDeviceInfo.TYPE_WIRED_HEADPHONES ||
            it.type == AudioDeviceInfo.TYPE_WIRED_HEADSET ||
            it.type == AudioDeviceInfo.TYPE_BLUETOOTH_A2DP ||
            it.type == AudioDeviceInfo.TYPE_USB_HEADSET ||
            it.type == AudioDeviceInfo.TYPE_USB_DEVICE
        }
        return preferred?.let { deviceKey(it) }
    }

    fun start(context: Context) {
        val applicationContext = context.applicationContext
        appContext = applicationContext
        val audioManager = applicationContext.getSystemService(Context.AUDIO_SERVICE) as AudioManager
        stop()

        callback = object : AudioDeviceCallback() {
            override fun onAudioDevicesAdded(addedDevices: Array<out AudioDeviceInfo>) {
                addedDevices.forEach { device ->
                    val key = deviceKey(device)
                    ProfileStore.findForDevice(key)?.let { profile ->
                        scope.launch { ProfileStore.apply(profile) }
                    }
                }
            }

            override fun onAudioDevicesRemoved(removedDevices: Array<out AudioDeviceInfo>) {
                val defaultProfile = ProfileStore.profiles.value.firstOrNull { it.deviceKey == null }
                defaultProfile?.let { ProfileStore.apply(it) }
            }
        }

        audioManager.registerAudioDeviceCallback(callback, null)

        currentDeviceKey(applicationContext)?.let { key ->
            ProfileStore.findForDevice(key)?.let { ProfileStore.apply(it) }
        }
    }

    fun stop() {
        val context = appContext
        val currentCallback = callback
        if (context != null && currentCallback != null) {
            val audioManager = context.getSystemService(Context.AUDIO_SERVICE) as AudioManager
            runCatching { audioManager.unregisterAudioDeviceCallback(currentCallback) }
        }
        callback = null
    }
}
