package com.soundcontrolprox.data

import android.content.Context
import androidx.datastore.preferences.core.edit
import androidx.datastore.preferences.core.stringPreferencesKey
import androidx.datastore.preferences.preferencesDataStore
import com.soundcontrolprox.audio.AudioEngine
import kotlinx.coroutines.flow.MutableStateFlow
import kotlinx.coroutines.flow.asStateFlow
import kotlinx.coroutines.flow.first
import org.json.JSONArray
import org.json.JSONObject

private val Context.profileDataStore by preferencesDataStore(name = "sound_profiles")

data class SoundProfile(
    val name: String,
    val eqLevels: List<Int>,
    val bass: Int,
    val virtualizer: Int,
    val loudness: Float,
    val deviceKey: String? = null
)

object ProfileStore {
    private val KEY = stringPreferencesKey("profiles_json")
    private val _profiles = MutableStateFlow<List<SoundProfile>>(emptyList())
    val profiles = _profiles.asStateFlow()
    private val _active = MutableStateFlow<SoundProfile?>(null)
    val active = _active.asStateFlow()

    suspend fun load(context: Context) {
        val json = context.profileDataStore.data.first()[KEY] ?: "[]"
        val array = JSONArray(json)
        val result = mutableListOf<SoundProfile>()
        for (i in 0 until array.length()) {
            val item = array.getJSONObject(i)
            val eq = mutableListOf<Int>()
            val eqArray = item.getJSONArray("eq")
            for (j in 0 until eqArray.length()) eq.add(eqArray.getInt(j))
            result.add(
                SoundProfile(
                    name = item.getString("name"),
                    eqLevels = eq,
                    bass = item.getInt("bass"),
                    virtualizer = item.getInt("virtualizer"),
                    loudness = item.getDouble("loudness").toFloat(),
                    deviceKey = if (item.isNull("deviceKey")) null else item.getString("deviceKey")
                )
            )
        }
        _profiles.value = result
    }

    suspend fun save(context: Context) {
        val array = JSONArray()
        _profiles.value.forEach { profile ->
            val item = JSONObject()
            item.put("name", profile.name)
            item.put("eq", JSONArray(profile.eqLevels))
            item.put("bass", profile.bass)
            item.put("virtualizer", profile.virtualizer)
            item.put("loudness", profile.loudness.toDouble())
            item.put("deviceKey", profile.deviceKey ?: JSONObject.NULL)
            array.put(item)
        }
        context.profileDataStore.edit { it[KEY] = array.toString() }
    }

    fun fromCurrentSettings(name: String, deviceKey: String?): SoundProfile {
        val levels = (0 until AudioEngine.bandCount()).map { AudioEngine.bandLevel(it.toShort()).toInt() }
        return SoundProfile(
            name = name,
            eqLevels = levels,
            bass = AudioEngine.bassStrength().toInt(),
            virtualizer = AudioEngine.virtualizerStrength().toInt(),
            loudness = AudioEngine.loudnessGain(),
            deviceKey = deviceKey
        )
    }

    suspend fun addOrUpdate(context: Context, profile: SoundProfile) {
        val current = _profiles.value.filterNot { it.name == profile.name }
        _profiles.value = current + profile
        save(context)
    }

    suspend fun delete(context: Context, name: String) {
        _profiles.value = _profiles.value.filterNot { it.name == name }
        if (_active.value?.name == name) _active.value = null
        save(context)
    }

    fun apply(profile: SoundProfile) {
        val count = AudioEngine.bandCount()
        profile.eqLevels.take(count).forEachIndexed { index, level ->
            AudioEngine.setBandLevel(index.toShort(), level.toShort())
        }
        AudioEngine.setBassStrength(profile.bass.toShort())
        AudioEngine.setVirtualizerStrength(profile.virtualizer.toShort())
        AudioEngine.setLoudnessGain(profile.loudness)
        AudioEngine.applySafeGain()
        _active.value = profile
    }

    fun findForDevice(deviceKey: String): SoundProfile? =
        _profiles.value.firstOrNull { it.deviceKey == deviceKey }
}
