package com.soundcontrolprox.ui.screens.tabs

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.soundcontrolprox.R
import com.soundcontrolprox.audio.DeviceProfileManager
import com.soundcontrolprox.data.ProfileStore
import kotlinx.coroutines.launch

@Composable
fun ProfilesTab() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val profiles by ProfileStore.profiles.collectAsState()

    Column(Modifier.fillMaxSize().padding(16.dp)) {
        Text(stringResource(R.string.profiles), style = MaterialTheme.typography.headlineSmall)
        Text(
            stringResource(R.string.profiles_note),
            style = MaterialTheme.typography.bodySmall,
            modifier = Modifier.padding(vertical = 8.dp)
        )
        if (profiles.isEmpty()) Text(stringResource(R.string.no_profiles))
        LazyColumn(Modifier.fillMaxSize()) {
            items(profiles) { profile ->
                Card(Modifier.fillMaxWidth().padding(vertical = 6.dp)) {
                    Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                        Text(profile.name, style = MaterialTheme.typography.titleMedium)
                        Text(
                            stringResource(R.string.bands) + ": " + profile.eqLevels.size +
                            " | " + stringResource(R.string.bass_boost) + ": " + profile.bass +
                            " | " + stringResource(R.string.virtualizer) + ": " + profile.virtualizer
                        )
                        Text(
                            if (profile.deviceKey == null) stringResource(R.string.general_profile)
                            else stringResource(R.string.device_profile) + ": " + profile.deviceKey
                        )
                        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                            Button(onClick = { ProfileStore.apply(profile) }) {
                                Text(stringResource(R.string.activate))
                            }
                            OutlinedButton(onClick = {
                                scope.launch {
                                    val key = DeviceProfileManager.currentDeviceKey(context)
                                    ProfileStore.addOrUpdate(context, profile.copy(deviceKey = key))
                                }
                            }) { Text(stringResource(R.string.link_device)) }
                            OutlinedButton(onClick = {
                                scope.launch { ProfileStore.delete(context, profile.name) }
                            }) { Text(stringResource(R.string.delete)) }
                        }
                    }
                }
            }
        }
    }
}
