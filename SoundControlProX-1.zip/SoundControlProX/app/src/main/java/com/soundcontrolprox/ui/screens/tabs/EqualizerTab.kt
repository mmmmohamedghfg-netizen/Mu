package com.soundcontrolprox.ui.screens.tabs

import androidx.compose.foundation.layout.ExperimentalLayoutApi
import androidx.compose.foundation.layout.FlowRow
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.rememberScrollState
import androidx.compose.foundation.verticalScroll
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.platform.LocalContext
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.unit.dp
import com.soundcontrolprox.R
import com.soundcontrolprox.audio.AudioEngine
import com.soundcontrolprox.audio.DeviceProfileManager
import com.soundcontrolprox.data.ProfileStore
import kotlinx.coroutines.launch

@OptIn(ExperimentalLayoutApi::class)
@Composable
fun EqualizerTab() {
    val context = LocalContext.current
    val scope = rememberCoroutineScope()
    val caps by AudioEngine.capabilities.collectAsState()
    val enabled by AudioEngine.enabled.collectAsState()
    val presets = remember(caps.bandCount) { AudioEngine.presetNames() }
    var profileName by remember { mutableStateOf("") }

    Column(
        Modifier.fillMaxSize().padding(16.dp).verticalScroll(rememberScrollState()),
        verticalArrangement = Arrangement.spacedBy(12.dp)
    ) {
        Text(stringResource(R.string.equalizer), style = MaterialTheme.typography.headlineSmall)

        if (!caps.equalizer) {
            Card {
                Text(
                    text = stringResource(R.string.equalizer_unsupported),
                    modifier = Modifier.padding(16.dp)
                )
            }
            return@Column
        }

        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            Button(onClick = { AudioEngine.setEnabled(!enabled) }) {
                Text(if (enabled) stringResource(R.string.disable) else stringResource(R.string.enable))
            }
            OutlinedButton(onClick = {
                AudioEngine.resetEqualizer()
                AudioEngine.applySafeGain()
            }) { Text(stringResource(R.string.reset)) }
            OutlinedButton(onClick = { AudioEngine.applySafeGain() }) {
                Text(stringResource(R.string.safe_gain))
            }
        }

        if (presets.isNotEmpty()) {
            Text(stringResource(R.string.presets))
            FlowRow(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                presets.forEachIndexed { index, name ->
                    OutlinedButton(onClick = {
                        AudioEngine.usePreset(index.toShort())
                        AudioEngine.applySafeGain()
                    }) { Text(name) }
                }
            }
        }

        val range = AudioEngine.bandRange()
        for (band in 0 until caps.bandCount) {
            val bandShort = band.toShort()
            var level by remember(band, caps) {
                mutableFloatStateOf(AudioEngine.bandLevel(bandShort).toFloat())
            }
            Text(
                text = AudioEngine.centerFrequency(bandShort).toString() + " Hz: " +
                    level.toInt().toString() + " dB"
            )
            Slider(
                value = level,
                onValueChange = {
                    level = it
                    AudioEngine.setBandLevel(bandShort, it.toInt().toShort())
                },
                valueRange = range.first.toFloat()..range.second.toFloat(),
                onValueChangeFinished = { AudioEngine.applySafeGain() }
            )
        }

        Card {
            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text(stringResource(R.string.save_current_profile))
                OutlinedTextField(
                    value = profileName,
                    onValueChange = { profileName = it },
                    label = { Text(stringResource(R.string.profile_name)) },
                    modifier = Modifier.fillMaxWidth()
                )
                Button(
                    enabled = profileName.isNotBlank(),
                    onClick = {
                        scope.launch {
                            val deviceKey = DeviceProfileManager.currentDeviceKey(context)
                            ProfileStore.addOrUpdate(
                                context,
                                ProfileStore.fromCurrentSettings(profileName.trim(), deviceKey)
                            )
                            profileName = ""
                        }
                    }
                ) { Text(stringResource(R.string.save)) }
            }
        }
    }
}
