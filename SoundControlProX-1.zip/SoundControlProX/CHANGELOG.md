# Changelog

## 1.1.1
- Fixed Equalizer band range type mismatch.
- Replaced unavailable LoudnessEnhancer.setGain with setTargetGain.
- Fixed Compose Text modifier usage and opted in to ExperimentalLayoutApi.
- Migrated kotlinOptions to compilerOptions.
- Workflow now generates and uses a Gradle 8.9 wrapper for AGP compatibility.

## 1.1.0
- Added smart sound profiles with DataStore persistence.
- Added audio-device profile linking and automatic profile application.
- Added safe-gain compensation after equalizer changes.
